Simple test package

# Reminder for me: build and distribute package

# pip install build

# don't use setup.py any more, use pyproject.toml
# python -m build

# make it a git repo and send it to 
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/VesaApaja/tst_pckg.git
git push -u origin main